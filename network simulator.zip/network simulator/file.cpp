#include <iostream>
#include <vector>
#include <queue>
#include <cstdlib>
#include <ctime>

using namespace std;

// Structure to represent an edge in the graph
struct Edge {
    int src, dest, weight;
};

// Comparator function for the priority queue
struct CompareEdges {
    bool operator()(const Edge& e1, const Edge& e2) {
        return e1.weight > e2.weight; // Min heap based on edge weights
    }
};

// Function to create a complete weighted undirected graph
vector<Edge> createGraph(int numNodes) {
    vector<Edge> graph;
    for (int i = 0; i < numNodes; ++i) {
        for (int j = i + 1; j < numNodes; ++j) {
            int weight = rand() % 100 + 1; // Random weight between 1 and 100
            graph.push_back({i, j, weight});
        }
    }
    return graph;
}

// Function to determine the order of transmission using a priority queue
vector<Edge> determineTransmissionOrder(const vector<Edge>& graph) {
    vector<Edge> transmissionOrder;
    priority_queue<Edge, vector<Edge>, CompareEdges> pq(graph.begin(), graph.end());

    while (!pq.empty()) {
        Edge currEdge = pq.top();
        pq.pop();
        transmissionOrder.push_back(currEdge);
    }

    return transmissionOrder;
}

int main() {
    srand(time(NULL));

    int numNodes;
    cout << "Enter the number of nodes: ";
    cin >> numNodes;

    vector<Edge> graph = createGraph(numNodes);
    vector<Edge> transmissionOrder = determineTransmissionOrder(graph);

    cout << "Transmission order of packets:\n";
    for (const Edge& edge : transmissionOrder) {
        cout << "Node " << edge.src << " to Node " << edge.dest << " with weight " << edge.weight << "\n";
    }

    return 0;
}
